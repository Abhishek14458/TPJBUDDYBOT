#include <Arduino.h>
#include <ESP32Servo.h>
#include <WiFi.h>
#include <WebServer.h>

// ====== Wi-Fi Credentials ======
const char* ssid = "BuddyBot";
const char* password = "12345678";

// ====== Pin Definitions ======
#define TRIG_PIN 23       // Ultrasonic sensor - Trigger pin
#define ECHO_PIN 22       // Ultrasonic sensor - Echo pin
#define SERVO_PIN 25      // Servo motor pin
#define TOUCH_PIN 4       // Touch sensor input pin
#define SPEAKER_PIN 15    // Speaker output pin
#define RED_PIN 26        // RGB LED - Red
#define BLUE_PIN 27       // RGB LED - Blue
#define GREEN_PIN 13      // RGB LED - Green (updated from 14)

#define DISTANCE_THRESHOLD 30 // Trigger distance for servo movement in cm

Servo myServo;
WebServer server(80);

// ====== System States ======
bool systemOn = false;
bool servoMoved = false;
bool playing = false;
bool externalStart = false;
bool playMusicFlag = false;
bool stopMusicFlag = false;

int melodyIndex = 0;

// ====== RGB Control (Common Anode LED Logic) ======
void setRGB(bool red, bool green, bool blue) {
  digitalWrite(RED_PIN, red ? LOW : HIGH);
  digitalWrite(GREEN_PIN, green ? LOW : HIGH);
  digitalWrite(BLUE_PIN, blue ? LOW : HIGH);
}

// ====== Melody Data Structures ======
typedef struct {
  int frequency;
  int duration;
} Note;

// Melody 1: Twinkle Twinkle Little Star
Note melody1[] = {
  {262, 500}, {262, 500}, {392, 500}, {392, 500},
  {440, 500}, {440, 500}, {392, 1000},
  {349, 500}, {349, 500}, {330, 500}, {330, 500},
  {294, 500}, {294, 500}, {262, 1000}
};
int length1 = sizeof(melody1) / sizeof(Note);

// Melody 2: Mary Had a Little Lamb
Note melody2[] = {
  {330, 500}, {294, 500}, {262, 500}, {294, 500},
  {330, 500}, {330, 500}, {330, 1000},
  {294, 500}, {294, 500}, {294, 1000},
  {330, 500}, {392, 500}, {392, 1000}
};
int length2 = sizeof(melody2) / sizeof(Note);

// Melody 3: Baby Shark
Note melody3[] = {
  {392, 250}, {392, 250}, {392, 250}, {392, 250},
  {392, 250}, {392, 250}, {440, 500},
  {392, 500}, {349, 500}, {262, 1000}
};
int length3 = sizeof(melody3) / sizeof(Note);

// ====== Touch Sensor Logic ======
void handleTouch() {
  static bool waitingForRelease = false;
  if (servoMoved && digitalRead(TOUCH_PIN) == HIGH && !waitingForRelease) {
    unsigned long startTime = millis();
    while (digitalRead(TOUCH_PIN) == HIGH) {
      if (millis() - startTime >= 2000) {
        melodyIndex = (melodyIndex + 1) % 3;
        Serial.print("Switched to Melody: ");
        Serial.println(melodyIndex);
        waitingForRelease = true;
        break;
      }
      delay(10);
    }
  }
  if (digitalRead(TOUCH_PIN) == LOW) {
    waitingForRelease = false;
  }
}

// ====== Speaker Logic ======
void playNote(int freq, int dur) {
  int channel = 0;
  if (freq == 0) { delay(dur); return; }
  ledcAttachPin(SPEAKER_PIN, channel);
  ledcSetup(channel, freq * 2, 10);
  ledcWrite(channel, 512);
  delay(dur);
  ledcWrite(channel, 0);
  delay(20);
  ledcDetachPin(SPEAKER_PIN);
}

void playMelody(Note *melody, int len) {
  for (int i = 0; i < len && !stopMusicFlag; i++) {
    handleTouch();
    playNote(melody[i].frequency, melody[i].duration);
    delay(50);
  }
  stopMusicFlag = false;
}

// ====== Web Interface ======
// ======  (generated with help of ChatGPT) ======
void handleRoot() {
  server.send(200, "text/html", R"rawliteral(
    <!DOCTYPE html>
    <html>
    <head>
      <title>BuddyBot Control</title>
      <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f5f5f5; text-align: center; margin-top: 60px; }
        h2 { color: #333; margin-bottom: 30px; }
        .btn-container { display: flex; justify-content: center; gap: 20px; flex-wrap: wrap; }
        button {
          background-color: #007BFF;
          color: white;
          padding: 14px 30px;
          font-size: 18px;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          transition: background 0.3s ease;
        }
        button:hover { background-color: #0056b3; }
      </style>
    </head>
    <body>
      <h2>BuddyBot IoT Control Panel</h2>
      <div class="btn-container">
        <button onclick="fetch('/start')">Activate System</button>
        <button onclick="fetch('/play')">Play Music</button>
        <button onclick="fetch('/stop')">Stop Music</button>
      </div>
    </body>
    </html>
  )rawliteral");
}

void handleStartSystem() {
  Serial.println("IoT Triggered: Activate System");
  externalStart = true;
  server.send(200, "text/plain", "System activated");
}

void handlePlayMusic() {
  playMusicFlag = true;
  stopMusicFlag = false;
  Serial.println("IoT: Play Music");
  server.send(200, "text/plain", "Music playing");
}

void handleStopMusic() {
  stopMusicFlag = true;
  playing = false;
  Serial.println("IoT: Stop Music");
  server.send(200, "text/plain", "Music stopped");
}

// ====== Setup ======
void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(TOUCH_PIN, INPUT);
  pinMode(RED_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  pinMode(BLUE_PIN, OUTPUT);
  setRGB(false, false, false);

  myServo.attach(SERVO_PIN);
  myServo.write(0);

  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500); Serial.print(".");
  }
  Serial.println("\n Connected!");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);
  server.on("/start", handleStartSystem);
  server.on("/play", handlePlayMusic);
  server.on("/stop", handleStopMusic);
  server.begin();

  Serial.println("System Initialized. Touch to turn ON.");
}

// ====== Main Loop ======
void loop() {
  server.handleClient();
  handleTouch();

  if ((digitalRead(TOUCH_PIN) == HIGH || externalStart) && !systemOn && !servoMoved) {
    systemOn = true;
    externalStart = false;
    Serial.println("System ON");
    setRGB(false, false, true);
    delay(1000);
  }

  float duration, distance;
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  duration = pulseIn(ECHO_PIN, HIGH);
  distance = (duration * 0.0343) / 2;

  if (systemOn && !servoMoved && distance > 0 && distance <= DISTANCE_THRESHOLD) {
    Serial.println("Object Detected. Moving Servo...");
    setRGB(false, true, false);
    myServo.write(90);
    delay(3000);
    myServo.write(0);
    delay(300);
    myServo.detach();
    servoMoved = true;
    systemOn = false;
    Serial.println("Servo Done. Playing Music...");
    setRGB(true, false, false);
    delay(1000);
    setRGB(false, false, false);
    playing = true;
  }

  if ((servoMoved && playing) || playMusicFlag) {
    playMusicFlag = false;
    playing = true;
    switch (melodyIndex) {
      case 0: playMelody(melody1, length1); break;
      case 1: playMelody(melody2, length2); break;
      case 2: playMelody(melody3, length3); break;
    }
    delay(1000);
  }
}
